package com.example.habitohero.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.habitohero.data.entities.Habit;
import com.example.habitohero.data.entities.HabitCheck;
import com.example.habitohero.data.entities.PlayerProgress;

import java.util.List;

@Dao
public interface HabitDao {

    // Operações para Habit
    @Insert
    long insertHabit(Habit habit);

    @Update
    void updateHabit(Habit habit);

    @Query("SELECT * FROM habits ORDER BY createdAt DESC")
    LiveData<List<Habit>> getAllHabits();

    @Query("SELECT * FROM habits ORDER BY createdAt DESC")
    List<Habit> getAllHabitsDirect();

    @Query("SELECT * FROM habits WHERE id = :habitId")
    Habit getHabitById(long habitId);

    @Delete
    void deleteHabit(Habit habit);

    // Operações para HabitCheck
    @Insert
    void insertHabitCheck(HabitCheck habitCheck);

    @Query("SELECT * FROM habit_checks WHERE habitId = :habitId AND date >= :startDate AND date < :endDate")
    List<HabitCheck> getChecksForHabitAndDate(long habitId, long startDate, long endDate);

    @Query("SELECT COUNT(*) FROM habit_checks WHERE habitId = :habitId")
    int getCheckCountForHabit(long habitId);

    @Query("DELETE FROM habit_checks WHERE habitId = :habitId")
    void deleteChecksForHabit(long habitId);

    // NOVAS OPERAÇÕES PARA PLAYER PROGRESS (XP)
    @Insert
    void insertPlayerProgress(PlayerProgress playerProgress);

    @Update
    void updatePlayerProgress(PlayerProgress playerProgress);

    @Query("SELECT * FROM player_progress WHERE id = 1")
    PlayerProgress getPlayerProgress();

    @Query("SELECT COUNT(*) FROM player_progress")
    int getPlayerProgressCount();
}