package com.example.habitohero.ui.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.habitohero.R;
import com.example.habitohero.data.entities.Habit;
import com.example.habitohero.viewmodel.HabitViewModel;

import java.util.List;

public class StatisticsActivity extends AppCompatActivity {

    private HabitViewModel habitViewModel;
    private TextView tvTotalHabits, tvTotalXP, tvCurrentLevel;
    private TextView tvBestStreak, tvTotalCheckins, tvSuccessRate;
    private RecyclerView recyclerViewStats;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        Log.d("STATS_DEBUG", "StatisticsActivity iniciada");

        try {
            // Configurar toolbar
            if (getSupportActionBar() != null) {
                getSupportActionBar().setTitle("Estatísticas");
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }

            // Inicializar ViewModel
            habitViewModel = new ViewModelProvider(this).get(HabitViewModel.class);
            Log.d("STATS_DEBUG", "ViewModel inicializado");

            // Inicializar views
            initViews();
            Log.d("STATS_DEBUG", "Views inicializadas");

            // Observar dados
            observeData();
            Log.d("STATS_DEBUG", "Observers configurados");

        } catch (Exception e) {
            Log.e("STATS_DEBUG", "Erro no onCreate: " + e.getMessage(), e);
            finish(); // Fecha a activity se houver erro
        }
    }

    private void initViews() {
        try {
            tvTotalHabits = findViewById(R.id.tv_total_habits);
            tvTotalXP = findViewById(R.id.tv_total_xp);
            tvCurrentLevel = findViewById(R.id.tv_current_level);
            tvBestStreak = findViewById(R.id.tv_best_streak);
            tvTotalCheckins = findViewById(R.id.tv_total_checkins);
            tvSuccessRate = findViewById(R.id.tv_success_rate);
            recyclerViewStats = findViewById(R.id.recyclerViewStats);
            Log.d("STATS_DEBUG", "Todas as views encontradas");
        } catch (Exception e) {
            Log.e("STATS_DEBUG", "Erro ao inicializar views: " + e.getMessage());
            throw e;
        }
    }

    private void observeData() {
        // Observar lista de hábitos
        habitViewModel.getAllHabits().observe(this, habits -> {
            if (habits != null) {
                Log.d("STATS_DEBUG", "Hábitos recebidos: " + habits.size());
                updateStatistics(habits);
            } else {
                Log.d("STATS_DEBUG", "Lista de hábitos é null");
            }
        });

        // Observar XP
        habitViewModel.getTotalXP().observe(this, xp -> {
            if (xp != null) {
                Log.d("STATS_DEBUG", "XP recebido: " + xp);
                tvTotalXP.setText(xp + " XP");
                tvCurrentLevel.setText("Nível " + habitViewModel.getLevel());
            }
        });
    }

    private void updateStatistics(List<Habit> habits) {
        try {
            // Calcular estatísticas
            int totalHabits = habits.size();
            int totalCheckins = calculateTotalCheckins(habits);
            int bestStreak = calculateBestStreak(habits);
            double successRate = calculateSuccessRate(habits);

            Log.d("STATS_DEBUG", "Estatísticas calculadas: " + totalHabits + " hábitos, " + bestStreak + " streak");

            // Atualizar UI
            tvTotalHabits.setText(String.valueOf(totalHabits));
            tvBestStreak.setText(bestStreak + " dias");
            tvTotalCheckins.setText(String.valueOf(totalCheckins));
            tvSuccessRate.setText(String.format("%.1f%%", successRate));

            // Configurar RecyclerView para estatísticas detalhadas
            setupStatsRecyclerView(habits);

        } catch (Exception e) {
            Log.e("STATS_DEBUG", "Erro ao atualizar estatísticas: " + e.getMessage(), e);
        }
    }

    private int calculateTotalCheckins(List<Habit> habits) {
        int total = 0;
        for (Habit habit : habits) {
            try {
                int progress = habitViewModel.getProgressForHabit(habit.getId());
                total += (progress * habit.getDaysGoal()) / 100;
            } catch (Exception e) {
                Log.e("STATS_DEBUG", "Erro ao calcular check-ins para: " + habit.getTitle(), e);
            }
        }
        return total;
    }

    private int calculateBestStreak(List<Habit> habits) {
        int bestStreak = 0;
        for (Habit habit : habits) {
            if (habit.getLongestStreak() > bestStreak) {
                bestStreak = habit.getLongestStreak();
            }
        }
        return bestStreak;
    }

    private double calculateSuccessRate(List<Habit> habits) {
        if (habits.isEmpty()) return 0.0;

        double totalRate = 0;
        for (Habit habit : habits) {
            try {
                int progress = habitViewModel.getProgressForHabit(habit.getId());
                totalRate += progress;
            } catch (Exception e) {
                Log.e("STATS_DEBUG", "Erro ao calcular progresso para: " + habit.getTitle(), e);
            }
        }
        return totalRate / habits.size();
    }

    private void setupStatsRecyclerView(List<Habit> habits) {
        try {
            recyclerViewStats.setLayoutManager(new LinearLayoutManager(this));

            // Adapter simples para mostrar estatísticas por hábito
            recyclerViewStats.setAdapter(new RecyclerView.Adapter() {
                @NonNull
                @Override
                public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                    TextView textView = new TextView(parent.getContext());
                    textView.setPadding(50, 30, 50, 30);
                    textView.setTextSize(14);
                    textView.setLayoutParams(new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                    ));
                    return new RecyclerView.ViewHolder(textView) {};
                }

                @Override
                public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
                    try {
                        Habit habit = habits.get(position);
                        int progress = habitViewModel.getProgressForHabit(habit.getId());

                        TextView textView = (TextView) holder.itemView;
                        String statsText = String.format(
                                "📌 %s\n   🔥 Streak: %d dias\n   📈 Progresso: %d%%\n   🎯 Meta: %d dias",
                                habit.getTitle(),
                                habit.getCurrentStreak(),
                                progress,
                                habit.getDaysGoal()
                        );
                        textView.setText(statsText);
                    } catch (Exception e) {
                        Log.e("STATS_DEBUG", "Erro no bindViewHolder: " + e.getMessage());
                    }
                }

                @Override
                public int getItemCount() {
                    return habits.size();
                }
            });

            Log.d("STATS_DEBUG", "RecyclerView configurado com " + habits.size() + " itens");
        } catch (Exception e) {
            Log.e("STATS_DEBUG", "Erro ao configurar RecyclerView: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}