package com.example.habitohero.ui.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.habitohero.R;
import com.example.habitohero.data.entities.Habit;

import java.util.ArrayList;
import java.util.List;

public class HabitAdapter extends RecyclerView.Adapter<HabitAdapter.HabitViewHolder> {
    public List<Habit> habits;
    private OnHabitCheckListener checkListener;
    private OnHabitDeleteListener deleteListener;

    public interface OnHabitCheckListener {
        void onHabitCheck(long habitId);
    }

    public interface OnHabitDeleteListener {
        void onHabitDelete(Habit habit);
    }

    public HabitAdapter(OnHabitCheckListener checkListener, OnHabitDeleteListener deleteListener) {
        this.habits = new ArrayList<>();
        this.checkListener = checkListener;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public HabitViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_habit, parent, false);
        return new HabitViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HabitViewHolder holder, int position) {
        Habit habit = habits.get(position);

        // NOME DO HÁBITO
        holder.tvHabitTitle.setText(habit.getTitle());

        // DESCRIÇÃO
        if (habit.getDescription() != null && !habit.getDescription().isEmpty()) {
            holder.tvHabitDescription.setText("(" + habit.getDescription() + ")");
            holder.tvHabitDescription.setVisibility(View.VISIBLE);
        } else {
            holder.tvHabitDescription.setVisibility(View.GONE);
        }

        // STREAK - NOVO CÓDIGO ADICIONADO
        if (habit.getCurrentStreak() > 0) {
            holder.tvHabitStreak.setText("🔥 " + habit.getCurrentStreak() + " dias");
            holder.tvHabitStreak.setVisibility(View.VISIBLE);

            // Cores dinâmicas baseadas no streak
            if (habit.getCurrentStreak() >= 7) {
                holder.tvHabitStreak.setTextColor(Color.parseColor("#FF6B35")); // Laranja forte
                holder.tvHabitStreak.setBackgroundColor(Color.parseColor("#3A2F2A"));
            } else if (habit.getCurrentStreak() >= 3) {
                holder.tvHabitStreak.setTextColor(Color.parseColor("#DE4E00")); // Laranja
                holder.tvHabitStreak.setBackgroundColor(Color.parseColor("#2A2F3A"));
            } else {
                holder.tvHabitStreak.setTextColor(Color.parseColor("#413A8E")); // Roxo
                holder.tvHabitStreak.setBackgroundColor(Color.parseColor("#2A2A3A"));
            }
        } else {
            holder.tvHabitStreak.setVisibility(View.GONE);
        }

        // BOTÃO DE CHECK-IN
        holder.btnCheck.setOnClickListener(v -> {
            if (checkListener != null) {
                checkListener.onHabitCheck(habit.getId());

                // Feedback visual
                holder.btnCheck.setText("✓");
                holder.btnCheck.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), android.R.color.holo_green_dark));
                holder.btnCheck.setClickable(false);

                // Reverter após 2 segundos
                holder.btnCheck.postDelayed(() -> {
                    holder.btnCheck.setText("Check");
                    holder.btnCheck.setBackgroundResource(R.drawable.button_check_background);
                    holder.btnCheck.setClickable(true);
                }, 2000);
            }
        });

        // Clique longo para excluir
        holder.itemView.setOnLongClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onHabitDelete(habit);
            }
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return habits != null ? habits.size() : 0;
    }

    public void setHabits(List<Habit> habits) {
        if (habits != null) {
            this.habits = habits;
        } else {
            this.habits = new ArrayList<>();
        }
        notifyDataSetChanged();
    }

    public static class HabitViewHolder extends RecyclerView.ViewHolder {
        TextView tvHabitTitle;
        TextView tvHabitDescription;
        TextView tvHabitStreak; // NOVO: TextView do streak
        TextView btnCheck;

        public HabitViewHolder(@NonNull View itemView) {
            super(itemView);
            tvHabitTitle = itemView.findViewById(R.id.tv_habit_title);
            tvHabitDescription = itemView.findViewById(R.id.tv_habit_description);
            tvHabitStreak = itemView.findViewById(R.id.tv_habit_streak); // NOVO: Inicializar o streak
            btnCheck = itemView.findViewById(R.id.btn_check);
        }
    }
}