package com.example.habitohero.data.entities;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.habitohero.data.converters.DateConverter;

import java.util.Date;

@Entity(
        tableName = "habit_checks",
        foreignKeys = @ForeignKey(
                entity = Habit.class,
                parentColumns = "id",
                childColumns = "habitId",
                onDelete = ForeignKey.CASCADE
        ),
        indices = {@Index(value = {"habitId", "date"}, unique = true)}
)
@TypeConverters(DateConverter.class)
public class HabitCheck {
    @PrimaryKey(autoGenerate = true)
    private long id;

    private long habitId;
    private Date date;

    public HabitCheck() {
        this.date = new Date();
    }

    // Getters e Setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getHabitId() { return habitId; }
    public void setHabitId(long habitId) { this.habitId = habitId; }

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }
}