package com.example.habitohero.data.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.habitohero.data.converters.DateConverter;

import java.util.Date;

@Entity(tableName = "habits")
@TypeConverters(DateConverter.class)
public class Habit {
    @PrimaryKey(autoGenerate = true)
    private long id;

    private String title;
    private String description;
    private String icon;
    private String colorHex;
    private int daysGoal;
    private Date createdAt;
    private int xpPerCheck;

    // NOVOS CAMPOS PARA STREAK
    private int currentStreak;      // Dias consecutivos atuais
    private int longestStreak;      // Maior sequência já alcançada
    private Date lastCheckDate;     // Data do último check-in

    public Habit() {
        this.createdAt = new Date();
        this.xpPerCheck = 5;
        this.currentStreak = 0;
        this.longestStreak = 0;
        this.lastCheckDate = null;
    }

    // Getters e Setters existentes...
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    public String getColorHex() { return colorHex; }
    public void setColorHex(String colorHex) { this.colorHex = colorHex; }

    public int getDaysGoal() { return daysGoal; }
    public void setDaysGoal(int daysGoal) { this.daysGoal = daysGoal; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }

    public int getXpPerCheck() { return xpPerCheck; }
    public void setXpPerCheck(int xpPerCheck) { this.xpPerCheck = xpPerCheck; }

    // NOVOS GETTERS E SETTERS PARA STREAK
    public int getCurrentStreak() { return currentStreak; }
    public void setCurrentStreak(int currentStreak) { this.currentStreak = currentStreak; }

    public int getLongestStreak() { return longestStreak; }
    public void setLongestStreak(int longestStreak) { this.longestStreak = longestStreak; }

    public Date getLastCheckDate() { return lastCheckDate; }
    public void setLastCheckDate(Date lastCheckDate) { this.lastCheckDate = lastCheckDate; }

    // Métodos para o Room conseguir comparar e excluir
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Habit habit = (Habit) o;
        return id == habit.id;
    }

    @Override
    public int hashCode() {
        return Long.hashCode(id);
    }

    @Override
    public String toString() {
        return "Habit{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", currentStreak=" + currentStreak +
                ", longestStreak=" + longestStreak +
                '}';
    }
}