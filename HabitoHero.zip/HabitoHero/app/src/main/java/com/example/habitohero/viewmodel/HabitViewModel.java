package com.example.habitohero.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.habitohero.data.entities.Habit;
import com.example.habitohero.data.entities.HabitCheck;
import com.example.habitohero.data.repository.HabitRepository;

import java.util.List;

public class HabitViewModel extends AndroidViewModel {
    private HabitRepository repository;
    private LiveData<List<Habit>> allHabits;
    private MutableLiveData<Integer> totalXP;

    public HabitViewModel(Application application) {
        super(application);
        repository = new HabitRepository(application);
        allHabits = repository.getAllHabits();
        totalXP = new MutableLiveData<>();

        // Carregar XP do banco
        loadTotalXP();
    }

    public LiveData<List<Habit>> getAllHabits() {
        return allHabits;
    }

    public void insertHabit(Habit habit) {
        repository.insertHabit(habit);
    }

    public void deleteHabit(Habit habit) {
        repository.deleteHabit(habit);
    }

    public void deleteHabitById(long habitId) {
        repository.deleteHabitById(habitId);
    }

    public void testDatabase() {
        repository.testDatabaseConnection();
    }

    public void checkHabit(long habitId) {
        if (!repository.hasCheckedToday(habitId)) {
            HabitCheck habitCheck = new HabitCheck();
            habitCheck.setHabitId(habitId);
            repository.insertHabitCheck(habitCheck);

            // Adicionar XP
            addXP(10);
        }
    }

    public int getProgressForHabit(long habitId) {
        return repository.getProgressForHabit(habitId);
    }

    public boolean hasCheckedToday(long habitId) {
        return repository.hasCheckedToday(habitId);
    }

    public LiveData<Integer> getTotalXP() {
        return totalXP;
    }

    public int getLevel() {
        Integer xp = totalXP.getValue();
        if (xp == null) return 1;
        return (xp / 100) + 1;
    }

    public int getXPForNextLevel() {
        Integer xp = totalXP.getValue();
        if (xp == null) return 100;
        return 100 - (xp % 100);
    }

    public int getCurrentLevelProgress() {
        Integer xp = totalXP.getValue();
        if (xp == null) return 0;
        return xp % 100;
    }

    private void addXP(int xpToAdd) {
        Integer currentXP = totalXP.getValue();
        if (currentXP == null) {
            currentXP = 0;
        }

        int newXP = currentXP + xpToAdd;
        totalXP.setValue(newXP);

        // SALVAR XP NO BANCO
        repository.saveXP(newXP);
    }

    private void loadTotalXP() {
        // Carregar XP do banco em uma thread background
        new Thread(() -> {
            int savedXP = repository.loadXP();
            totalXP.postValue(savedXP);
        }).start();
    }
}