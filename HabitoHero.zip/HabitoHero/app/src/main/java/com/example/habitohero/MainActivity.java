package com.example.habitohero;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.habitohero.data.entities.Habit;
import com.example.habitohero.ui.activities.CreateHabitActivity;
import com.example.habitohero.ui.activities.StatisticsActivity;
import com.example.habitohero.ui.adapters.HabitAdapter;
import com.example.habitohero.viewmodel.HabitViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity implements
        HabitAdapter.OnHabitCheckListener,
        HabitAdapter.OnHabitDeleteListener {

    private HabitViewModel habitViewModel;
    private RecyclerView recyclerView;
    private HabitAdapter adapter;

    // Activity Result Launcher para criar hábitos
    private final ActivityResultLauncher<Intent> createHabitLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    // Hábito criado com sucesso
                    Toast.makeText(this, "Hábito criado com sucesso!", Toast.LENGTH_SHORT).show();
                    // O LiveData vai atualizar automaticamente a lista
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // NOVO: Configurar status bar com cor escura
        getWindow().setStatusBarColor(Color.parseColor("#19181a"));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        // Inicializar ViewModel
        habitViewModel = new ViewModelProvider(this).get(HabitViewModel.class);

        // TESTAR BANCO DE DADOS
        habitViewModel.testDatabase();

        // Configurar RecyclerView
        recyclerView = findViewById(R.id.rv_habits);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new HabitAdapter(this, this);
        recyclerView.setAdapter(adapter);

        // CONFIGURAR FAB
        FloatingActionButton fab = findViewById(R.id.fab_add_habit);
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, CreateHabitActivity.class);
            createHabitLauncher.launch(intent);
        });

        // NOVO: Configurar header completo
        setupHeader();

        // NOVO: Configurar bottom navigation
        setupBottomNavigation();

        // Observar a lista de hábitos
        habitViewModel.getAllHabits().observe(this, habits -> {
            Log.d("HABIT_DEBUG", "Hábitos recebidos: " + (habits != null ? habits.size() : "null"));
            if (habits != null) {
                for (Habit habit : habits) {
                    Log.d("HABIT_DEBUG", "- " + habit.getTitle() + " (ID: " + habit.getId() + ")");
                }
            }
            adapter.setHabits(habits);
        });
    }

    // NOVO MÉTODO: Configurar header completo
    private void setupHeader() {
        // Configurar avatar
        ImageView ivAvatar = findViewById(R.id.iv_avatar);
        ivAvatar.setImageResource(R.drawable.avatar);

        // Configurar logo
        ImageView ivLogo = findViewById(R.id.iv_logo);
        ivLogo.setImageResource(R.drawable.logo);

        // Configurar saudação
        TextView tvGreeting = findViewById(R.id.tv_greeting);
        tvGreeting.setText("Olá, Herói!");

        // Observar XP para atualizar barra, nível e progresso
        habitViewModel.getTotalXP().observe(this, xp -> {
            TextView tvXP = findViewById(R.id.tv_xp);
            TextView tvLevel = findViewById(R.id.tv_level);
            ProgressBar progressLevel = findViewById(R.id.progress_level);
            TextView tvProgressPercent = findViewById(R.id.tv_progress_percent);

            if (xp != null) {
                int level = habitViewModel.getLevel();
                int progresso = habitViewModel.getCurrentLevelProgress();

                tvXP.setText(xp + " XP");
                tvLevel.setText("Nível " + level);
                progressLevel.setProgress(progresso);
                tvProgressPercent.setText(progresso + "%");

                // DEBUG
                Log.d("XP_DEBUG", "XP: " + xp + " | Nível: " + level + " | Progresso: " + progresso + "%");
            }
        });
    }

    // NOVO MÉTODO: Configurar Bottom Navigation
    private void setupBottomNavigation() {
        TextView tvHome = findViewById(R.id.tv_home);
        TextView tvStats = findViewById(R.id.tv_stats);
        TextView tvHabits = findViewById(R.id.tv_habits);
        TextView tvProfile = findViewById(R.id.tv_profile);

        // Home já está selecionado (cor laranja)
        tvHome.setTextColor(Color.parseColor("#de4e00"));
        tvHome.setTypeface(tvHome.getTypeface(), Typeface.BOLD);

        // Estatísticas - vai para StatisticsActivity
        tvStats.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, StatisticsActivity.class);
            startActivity(intent);
        });

        // Hábitos - vai para CreateHabitActivity
        tvHabits.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CreateHabitActivity.class);
            createHabitLauncher.launch(intent);
        });

        // Perfil - por enquanto não faz nada (ou cria uma ProfileActivity)
        tvProfile.setOnClickListener(v -> {
            Toast.makeText(this, "Perfil em desenvolvimento", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onHabitCheck(long habitId) {
        habitViewModel.checkHabit(habitId);

        // Buscar o hábito pelo ID para mostrar o nome
        List<Habit> currentHabits = adapter.habits;
        if (currentHabits != null) {
            for (Habit habit : currentHabits) {
                if (habit.getId() == habitId) {
                    Toast.makeText(this, habit.getTitle() + " completado! +10XP", Toast.LENGTH_SHORT).show();
                    break;
                }
            }
        }
    }

    @Override
    public void onHabitDelete(Habit habit) {
        // DEBUG DETALHADO
        System.out.println("MAIN ACTIVITY - RECEBENDO HÁBITO PARA EXCLUSÃO:");
        System.out.println("ID: " + habit.getId());
        System.out.println("Título: " + habit.getTitle());
        System.out.println("HashCode: " + habit.hashCode());
        System.out.println("Equals com si mesmo: " + habit.equals(habit));

        // Confirmar exclusão - USANDO EXCLUSÃO POR ID
        new android.app.AlertDialog.Builder(this)
                .setTitle("Excluir Hábito")
                .setMessage("Tem certeza que deseja excluir \"" + habit.getTitle() + "\"?")
                .setPositiveButton("Excluir", (dialog, which) -> {
                    System.out.println("CONFIRMADO EXCLUSÃO DO HÁBITO ID: " + habit.getId());
                    // USAR EXCLUSÃO POR ID (MAIS SEGURO)
                    habitViewModel.deleteHabitById(habit.getId());
                    Toast.makeText(this, "Hábito excluído", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}