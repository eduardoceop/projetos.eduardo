package com.example.habitohero.ui.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.habitohero.R;
import com.example.habitohero.data.entities.Habit;
import com.example.habitohero.viewmodel.HabitViewModel;

public class CreateHabitActivity extends AppCompatActivity {

    private HabitViewModel habitViewModel;
    private EditText etTitle, etDescription;
    private RadioGroup rgDaysGoal;
    private TextView btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_habit);

        // Configurar status bar com cor escura
        getWindow().setStatusBarColor(Color.parseColor("#19181a"));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        habitViewModel = new ViewModelProvider(this).get(HabitViewModel.class);

        initViews();
        setupClickListeners();
    }

    private void initViews() {
        etTitle = findViewById(R.id.et_title);
        etDescription = findViewById(R.id.et_description);
        rgDaysGoal = findViewById(R.id.rg_days_goal);
        btnSave = findViewById(R.id.btn_save); // Agora é TextView
    }

    private void setupClickListeners() {
        btnSave.setOnClickListener(v -> saveHabit());
    }

    private void saveHabit() {
        String title = etTitle.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        if (title.isEmpty()) {
            etTitle.setError("Digite um título para o hábito");
            etTitle.requestFocus();
            return;
        }

        int daysGoal = getSelectedDaysGoal();

        Habit habit = new Habit();
        habit.setTitle(title);
        habit.setDescription(description);
        habit.setDaysGoal(daysGoal);
        habit.setColorHex("#de4e00"); // Cor laranja do tema
        habit.setIcon("ic_default_habit");

        habitViewModel.insertHabit(habit);

        Toast.makeText(this, "Hábito criado com sucesso!", Toast.LENGTH_SHORT).show();

        setResult(RESULT_OK);
        finish();
    }

    private int getSelectedDaysGoal() {
        int selectedId = rgDaysGoal.getCheckedRadioButtonId();

        if (selectedId == R.id.rb_21_days) return 21;
        if (selectedId == R.id.rb_30_days) return 30;
        if (selectedId == R.id.rb_66_days) return 66;

        return 21; // Padrão
    }
}