package com.example.habitohero.data.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.habitohero.data.AppDatabase;
import com.example.habitohero.data.dao.HabitDao;
import com.example.habitohero.data.entities.Habit;
import com.example.habitohero.data.entities.HabitCheck;
import com.example.habitohero.data.entities.PlayerProgress;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class HabitRepository {
    private HabitDao habitDao;
    private LiveData<List<Habit>> allHabits;
    private Executor executor;

    public HabitRepository(Application application) {
        AppDatabase database = AppDatabase.getDatabase(application);
        habitDao = database.habitDao();
        allHabits = habitDao.getAllHabits();
        executor = Executors.newSingleThreadExecutor();

        System.out.println("🔄 REPOSITORY INICIALIZADO");
        debugDatabaseState();
    }

    public LiveData<List<Habit>> getAllHabits() {
        return allHabits;
    }

    public void insertHabit(Habit habit) {
        executor.execute(() -> {
            try {
                long id = habitDao.insertHabit(habit);
                System.out.println("💾 HÁBITO SALVO NO BANCO: " + habit.getTitle() + " (ID: " + id + ")");

                // FORÇAR ATUALIZAÇÃO DO LIVEDATA
                forceRefreshHabits();
            } catch (Exception e) {
                System.out.println("❌ ERRO AO SALVAR HÁBITO: " + e.getMessage());
            }
        });
    }

    public void deleteHabitById(long habitId) {
        executor.execute(() -> {
            try {
                System.out.println("🗑️ INICIANDO EXCLUSÃO POR ID: " + habitId);

                // Buscar hábito
                Habit habit = habitDao.getHabitById(habitId);
                if (habit != null) {
                    System.out.println("✅ HÁBITO ENCONTRADO: " + habit.getTitle());

                    // Deletar checks
                    habitDao.deleteChecksForHabit(habitId);
                    System.out.println("✅ CHECKS EXCLUÍDOS");

                    // Deletar hábito
                    habitDao.deleteHabit(habit);
                    System.out.println("✅ HÁBITO EXCLUÍDO: " + habit.getTitle());

                    // FORÇAR ATUALIZAÇÃO DO LIVEDATA
                    forceRefreshHabits();

                    // Verificar exclusão
                    Habit habitApos = habitDao.getHabitById(habitId);
                    if (habitApos == null) {
                        System.out.println("🎉 EXCLUSÃO CONFIRMADA NO BANCO");
                    } else {
                        System.out.println("💥 HÁBITO AINDA EXISTE APÓS EXCLUSÃO!");
                    }
                } else {
                    System.out.println("❌ HÁBITO NÃO ENCONTRADO: " + habitId);
                }
            } catch (Exception e) {
                System.out.println("❌ ERRO NA EXCLUSÃO: " + e.getMessage());
            }
        });
    }

    // MÉTODO ATUALIZADO COM SISTEMA DE STREAKS
    public void insertHabitCheck(HabitCheck habitCheck) {
        executor.execute(() -> {
            try {
                if (!hasCheckedToday(habitCheck.getHabitId())) {
                    // Salvar o check-in
                    habitDao.insertHabitCheck(habitCheck);
                    System.out.println("✅ CHECK-IN SALVO: " + habitCheck.getHabitId());

                    // ATUALIZAR STREAK DO HÁBITO
                    updateHabitStreak(habitCheck.getHabitId());
                } else {
                    System.out.println("⏭️ CHECK-IN JÁ FEITO HOJE");
                }
            } catch (Exception e) {
                System.out.println("❌ ERRO NO CHECK-IN: " + e.getMessage());
            }
        });
    }

    // NOVO MÉTODO: ATUALIZAR STREAK DO HÁBITO
    private void updateHabitStreak(long habitId) {
        try {
            Habit habit = habitDao.getHabitById(habitId);
            if (habit != null) {
                Date today = new Date();
                Date lastCheckDate = habit.getLastCheckDate();

                int newStreak = calculateNewStreak(lastCheckDate, habit.getCurrentStreak());

                // Atualizar streaks
                habit.setCurrentStreak(newStreak);
                if (newStreak > habit.getLongestStreak()) {
                    habit.setLongestStreak(newStreak);
                }
                habit.setLastCheckDate(today);

                // Salvar hábito atualizado
                habitDao.updateHabit(habit);

                System.out.println("🔥 STREAK ATUALIZADO: " + habit.getTitle() +
                        " | Streak: " + newStreak +
                        " | Recorde: " + habit.getLongestStreak());
            }
        } catch (Exception e) {
            System.out.println("❌ ERRO AO ATUALIZAR STREAK: " + e.getMessage());
        }
    }

    // NOVO MÉTODO: CALCULAR NOVO STREAK
    private int calculateNewStreak(Date lastCheckDate, int currentStreak) {
        if (lastCheckDate == null) {
            // Primeiro check-in
            return 1;
        }

        Calendar lastCheck = Calendar.getInstance();
        lastCheck.setTime(lastCheckDate);

        Calendar today = Calendar.getInstance();
        today.setTime(new Date());

        Calendar yesterday = Calendar.getInstance();
        yesterday.setTime(new Date());
        yesterday.add(Calendar.DAY_OF_YEAR, -1);

        // Verificar se o último check-in foi ontem (streak continua)
        if (isSameDay(lastCheck, yesterday)) {
            return currentStreak + 1;
        }
        // Verificar se o último check-in foi hoje (já fez check-in)
        else if (isSameDay(lastCheck, today)) {
            return currentStreak;
        }
        // Streak quebrado (último check-in foi antes de ontem)
        else {
            return 1;
        }
    }

    // NOVO MÉTODO: VERIFICAR SE É O MESMO DIA
    private boolean isSameDay(Calendar cal1, Calendar cal2) {
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
    }

    public int getProgressForHabit(long habitId) {
        try {
            Habit habit = habitDao.getHabitById(habitId);
            if (habit != null && habit.getDaysGoal() > 0) {
                int checkCount = habitDao.getCheckCountForHabit(habitId);
                return (checkCount * 100) / habit.getDaysGoal();
            }
        } catch (Exception e) {
            System.out.println("❌ ERRO NO PROGRESSO: " + e.getMessage());
        }
        return 0;
    }

    public boolean hasCheckedToday(long habitId) {
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);

            long startOfDay = calendar.getTimeInMillis();
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            long endOfDay = calendar.getTimeInMillis();

            List<HabitCheck> todayChecks = habitDao.getChecksForHabitAndDate(
                    habitId, startOfDay, endOfDay
            );

            return !todayChecks.isEmpty();
        } catch (Exception e) {
            System.out.println("❌ ERRO AO VERIFICAR CHECK-IN: " + e.getMessage());
            return false;
        }
    }

    // MÉTODO CRÍTICO: Forçar atualização do LiveData
    private void forceRefreshHabits() {
        try {
            // Buscar dados diretamente do banco
            List<Habit> currentHabits = habitDao.getAllHabitsDirect();
            System.out.println("🔄 DADOS ATUAIS NO BANCO: " + (currentHabits != null ? currentHabits.size() : 0) + " hábitos");

            if (currentHabits != null) {
                for (Habit habit : currentHabits) {
                    System.out.println("   - " + habit.getTitle() + " (ID: " + habit.getId() + ")");
                }
            }
        } catch (Exception e) {
            System.out.println("❌ ERRO AO ATUALIZAR LIVEDATA: " + e.getMessage());
        }
    }

    // NOVOS MÉTODOS PARA XP PERSISTENTE
    public LiveData<Integer> getTotalXPLiveData() {
        MutableLiveData<Integer> xpLiveData = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                PlayerProgress progress = habitDao.getPlayerProgress();
                if (progress != null) {
                    xpLiveData.postValue(progress.getTotalXP());
                } else {
                    xpLiveData.postValue(0);
                }
            } catch (Exception e) {
                System.out.println("❌ ERRO AO BUSCAR XP: " + e.getMessage());
                xpLiveData.postValue(0);
            }
        });

        return xpLiveData;
    }

    public void saveXP(int totalXP) {
        executor.execute(() -> {
            try {
                PlayerProgress progress = habitDao.getPlayerProgress();
                int level = calculateLevel(totalXP);

                if (progress == null) {
                    // Primeira vez - criar novo progresso
                    progress = new PlayerProgress();
                    progress.setTotalXP(totalXP);
                    progress.setLevel(level);
                    habitDao.insertPlayerProgress(progress);
                    System.out.println("💾 XP SALVO PELA PRIMEIRA VEZ: " + totalXP + " (Nível " + level + ")");
                } else {
                    // Atualizar progresso existente
                    progress.setTotalXP(totalXP);
                    progress.setLevel(level);
                    habitDao.updatePlayerProgress(progress);
                    System.out.println("💾 XP ATUALIZADO: " + totalXP + " (Nível " + level + ")");
                }
            } catch (Exception e) {
                System.out.println("❌ ERRO AO SALVAR XP: " + e.getMessage());
            }
        });
    }

    public int loadXP() {
        try {
            PlayerProgress progress = habitDao.getPlayerProgress();
            if (progress != null) {
                System.out.println("📥 XP CARREGADO: " + progress.getTotalXP() + " (Nível " + progress.getLevel() + ")");
                return progress.getTotalXP();
            }
        } catch (Exception e) {
            System.out.println("❌ ERRO AO CARREGAR XP: " + e.getMessage());
        }
        return 0;
    }

    private int calculateLevel(int xp) {
        return (xp / 100) + 1;
    }

    // MÉTODO PARA DEBUG DO ESTADO DO BANCO
    private void debugDatabaseState() {
        executor.execute(() -> {
            try {
                System.out.println("🔍 DEBUG DO BANCO DE DADOS:");

                // Verificar hábitos diretamente
                List<Habit> habits = habitDao.getAllHabitsDirect();
                System.out.println("📊 TOTAL DE HÁBITOS NO BANCO: " + (habits != null ? habits.size() : 0));

                if (habits != null) {
                    for (Habit habit : habits) {
                        System.out.println("   🏷️ " + habit.getId() + " - " + habit.getTitle() +
                                " | Streak: " + habit.getCurrentStreak() +
                                " | Recorde: " + habit.getLongestStreak());
                    }
                }

            } catch (Exception e) {
                System.out.println("❌ ERRO NO DEBUG: " + e.getMessage());
            }
        });


    }

    public void testDatabaseConnection() {
    }

    public void deleteHabit(Habit habit) {
    }
}