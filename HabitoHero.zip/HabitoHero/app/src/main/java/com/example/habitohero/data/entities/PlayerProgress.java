package com.example.habitohero.data.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "player_progress")
public class PlayerProgress {
    @PrimaryKey
    private int id = 1; // Sempre 1, pois só temos um jogador

    private int totalXP;
    private int level;
    private String playerName;

    public PlayerProgress() {
        this.totalXP = 0;
        this.level = 1;
        this.playerName = "Herói";
    }

    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getTotalXP() { return totalXP; }
    public void setTotalXP(int totalXP) { this.totalXP = totalXP; }

    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = level; }

    public String getPlayerName() { return playerName; }
    public void setPlayerName(String playerName) { this.playerName = playerName; }
}