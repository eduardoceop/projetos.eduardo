package com.example.habitohero.data;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import android.content.Context;

import com.example.habitohero.data.dao.HabitDao;
import com.example.habitohero.data.entities.Habit;
import com.example.habitohero.data.entities.HabitCheck;
import com.example.habitohero.data.entities.PlayerProgress;

@Database(
        entities = {Habit.class, HabitCheck.class, PlayerProgress.class}, // ADICIONE PlayerProgress
        version = 3,  // MUDEI de 2 para 3
        exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {
    public abstract HabitDao habitDao();

    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "habitohero_database"
                            )
                            .fallbackToDestructiveMigration() // Recria o banco para novas versões
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}